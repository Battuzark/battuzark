import React from 'react';
import { createRoot } from 'react-dom/client';
import MeuDiarioDeTrader from './MeuDiarioDeTrader';
import './index.css';

createRoot(document.getElementById('root')).render(<MeuDiarioDeTrader />);
