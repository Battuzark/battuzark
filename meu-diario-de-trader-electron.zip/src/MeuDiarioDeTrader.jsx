import React, { useState, useMemo } from "react";
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, BarChart, Bar, CartesianGrid, Legend
} from "recharts";

const samplePlan = {
  capitalInicial: 2000,
  ativoPrincipal: "Mini Dólar",
  contratos: 1,
  limiteStops: 3,
  metaMensal: 1000,
  metaDiaria: null,
  gain: 150,
  loss: 70,
};

const sampleRecords = [
  { id: 1, date: "2025-11-01", result: 150, mood: "Bom", note: "Entrada favorável; parei." },
  { id: 2, date: "2025-11-02", result: -70, mood: "Ruim", note: "Stop inicial." },
  { id: 3, date: "2025-11-03", result: 200, mood: "Bom", note: "Boa leitura da tendência." },
  { id: 4, date: "2025-11-04", result: -210, mood: "Ruim", note: "3 stops: parei." },
];

export default function MeuDiarioDeTrader() {
  const [plan, setPlan] = useState(samplePlan);
  const [records, setRecords] = useState(sampleRecords);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [form, setForm] = useState({ date: today(), result: "", mood: "Neutro", note: "" });

  const resultadoAcumulado = useMemo(() => records.reduce((s, r) => s + Number(r.result || 0), 0), [records]);
  const capitalAtual = useMemo(() => plan.capitalInicial + resultadoAcumulado, [plan, resultadoAcumulado]);
  const lossMaxDiario = plan.loss * plan.limiteStops;
  const diasSobrevivencia = Math.floor(capitalAtual / lossMaxDiario);
  const metaDiariaCalc = plan.metaDiaria || Math.round(plan.metaMensal / 22);

  const patrimonioData = useMemo(() => {
    let acc = plan.capitalInicial;
    return records.slice().sort((a,b)=> new Date(a.date)-new Date(b.date)).map((r)=>{ acc+=Number(r.result||0); return { date: r.date, patrimonio: acc, resultado: Number(r.result||0) }; });
  }, [records, plan.capitalInicial]);

  const moodCounts = useMemo(()=>{ const map={Bom:0,Neutro:0,Ruim:0}; records.forEach(r=>map[r.mood]= (map[r.mood]||0)+1); return Object.entries(map).map(([name,value])=>({name,value})); }, [records]);

  const byWeekday = useMemo(()=>{ const map={Sun:0,Mon:0,Tue:0,Wed:0,Thu:0,Fri:0,Sat:0}; records.forEach(r=>{ const d=new Date(r.date); const key=[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"][d.getDay()]; map[key]=map[key]+Number(r.result||0); }); return Object.entries(map).map(([day,value])=>({day,value})); }, [records]);

  function handlePlanChange(key,value){ setPlan(p=>({...p,[key]:value})); }
  function addRecord(e){ e&&e.preventDefault(); const r={ id: Date.now(), date: form.date, result: Number(form.result||0), mood: form.mood, note: form.note }; setRecords(rs=>[...rs,r]); setForm({ date: today(), result: \"\", mood: \"Neutro\", note: \"\" }); setActiveTab(\"dashboard\"); }
  function deleteRecord(id){ setRecords(rs=>rs.filter(r=>r.id!==id)); }

  return (
    <div className=\"min-h-screen bg-gray-900 text-gray-100 p-6\">
      <div className=\"max-w-6xl mx-auto\">
        <header className=\"flex items-center justify-between mb-6\">
          <h1 className=\"text-2xl font-semibold\">Meu Diário de Trader</h1>
          <div className=\"space-x-2\">
            <button onClick={()=>setActiveTab('dashboard')} className=\"px-3 py-1 rounded bg-gray-800\">Dashboard</button>
            <button onClick={()=>setActiveTab('plan')} className=\"px-3 py-1 rounded bg-gray-800\">Plano</button>
            <button onClick={()=>setActiveTab('registro')} className=\"px-3 py-1 rounded bg-gray-800\">Registro</button>
            <button onClick={()=>setActiveTab('regras')} className=\"px-3 py-1 rounded bg-gray-800\">Regras</button>
          </div>
        </header>

        {activeTab==='dashboard' && <main>
          <section className=\"grid grid-cols-1 md:grid-cols-3 gap-4 mb-6\">
            <Card title=\"Resultado Acumulado\"><div className=\"text-2xl font-bold\">R$ {formatNumber(resultadoAcumulado)}</div><div className=\"text-sm mt-2\">Meta Mensal: R$ {formatNumber(plan.metaMensal)} • Progresso: {Math.round((resultadoAcumulado/plan.metaMensal)*100)}%</div></Card>
            <Card title=\"Capital Atual\"><div className=\"text-2xl font-bold\">R$ {formatNumber(capitalAtual)}</div><div className=\"text-sm mt-2\">Dias de Sobrevivência: {diasSobrevivencia}</div></Card>
            <Card title=\"Meta Diária (sugerida)\"><div className=\"text-2xl font-bold\">R$ {formatNumber(metaDiariaCalc)}</div><div className=\"text-sm mt-2\">Gain/Loss por trade: R$ {formatNumber(plan.gain)}/{formatNumber(plan.loss)}</div></Card>
          </section>

          <section className=\"grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6\">
            <Card title=\"Evolução do Capital\">
              <div style={{height:260}}><ResponsiveContainer><LineChart data={patrimonioData}><CartesianGrid strokeDasharray=\"3 3\" /><XAxis dataKey=\"date\" /><YAxis /><Tooltip /><Line type=\"monotone\" dataKey=\"patrimonio\" stroke=\"#34D399\" strokeWidth={2} dot={{r:3}} /></LineChart></ResponsiveContainer></div>
            </Card>

            <div className=\"space-y-4\">
              <Card title=\"Análise Emocional\">
                <div style={{height:220}}><ResponsiveContainer><PieChart><Pie data={moodCounts} dataKey=\"value\" nameKey=\"name\" innerRadius={50} outerRadius={80}>{moodCounts.map((entry,index)=>(<Cell key={`cell-${index}`} fill={moodColor(entry.name)} />))}</Pie><Tooltip /><Legend /></PieChart></ResponsiveContainer></div>
              </Card>

              <Card title=\"Resultados por Dia da Semana\">
                <div style={{height:160}}><ResponsiveContainer><BarChart data={byWeekday}><XAxis dataKey=\"day\" /><YAxis /><Tooltip /><Bar dataKey=\"value\" /></BarChart></ResponsiveContainer></div>
              </Card>
            </div>
          </section>

          <section><Card title=\"Calendário de Performance (lista)\"><div className=\"space-y-2 max-h-64 overflow-auto\">{records.slice().sort((a,b)=>new Date(b.date)-new Date(a.date)).map(r=>(<div key={r.id} className=\"flex items-center justify-between bg-gray-800 p-2 rounded\"><div><div className=\"font-medium\">{r.date} • {r.mood}</div><div className=\"text-sm text-gray-300\">R$ {formatNumber(r.result)} — {r.note}</div></div><div className=\"flex items-center gap-2\"><button onClick={()=>deleteRecord(r.id)} className=\"px-2 py-1 rounded bg-red-600\">Apagar</button></div></div>))}</div></Card></section>
        </main>}

        {activeTab==='plan' && <section><Card title=\"Plano de Trade (Campos editáveis)\"><div className=\"grid grid-cols-1 md:grid-cols-2 gap-4\">{['capitalInicial','ativoPrincipal','contratos','limiteStops','metaMensal','metaDiaria','gain','loss'].map(key=>(<div key={key}><div className=\"text-sm text-gray-300 mb-1\">{key}</div><div className=\"p-3 rounded bg-yellow-200\"><input className=\"w-full bg-transparent text-black\" value={plan[key]||''} onChange={(e)=>handlePlanChange(key, key==='ativoPrincipal'? e.target.value: Number(e.target.value))} /></div></div>))}</div><div className=\"mt-4 text-sm text-gray-300\">Relação Risco/Retorno: {(plan.gain/plan.loss).toFixed(2)}x • Loss máximo diário: R$ {formatNumber(lossMaxDiario)}</div></Card></section>}

        {activeTab==='registro' && <section><Card title=\"Novo Registro Diário\"><form onSubmit={addRecord} className=\"space-y-3\"><div className=\"grid grid-cols-1 md:grid-cols-3 gap-3\"><label className=\"flex flex-col\">Data<input type=\"date\" value={form.date} onChange={(e)=>setForm(f=>({...f,date:e.target.value}))} className=\"mt-1 bg-gray-800 p-2 rounded\" /></label><label className=\"flex flex-col\">Resultado (R$)<input type=\"number\" value={form.result} onChange={(e)=>setForm(f=>({...f,result:e.target.value}))} className={`mt-1 p-2 rounded ${form.result&&Number(form.result)>=0?'bg-green-900':'bg-red-900'}`} /></label><label className=\"flex flex-col\">Humor<select value={form.mood} onChange={(e)=>setForm(f=>({...f,mood:e.target.value}))} className=\"mt-1 bg-gray-800 p-2 rounded\"><option>Bom</option><option>Neutro</option><option>Ruim</option></select></label></div><label className=\"flex flex-col\">Diário de Bordo<textarea value={form.note} onChange={(e)=>setForm(f=>({...f,note:e.target.value}))} className=\"mt-1 bg-gray-800 p-2 rounded min-h-[120px]\" /></label><div className=\"flex gap-2\"><button type=\"submit\" className=\"flex-1 py-2 rounded bg-green-600\">Salvar Registro</button><button type=\"button\" onClick={()=>setForm({ date: today(), result: \"\", mood: \"Neutro\", note: \"\" })} className=\"py-2 px-4 rounded bg-gray-700\">Limpar</button></div></form></Card></section>}

        {activeTab==='regras' && <section><Card title=\"Minhas Regras (Disciplina)\"><RulesEditor /></Card></section>}

        <footer className=\"mt-8 text-sm text-gray-400\">Protótipo — substitua armazenamento local por backend real para produção.</footer>
      </div></div>
  );
}

function Card({title,children}){ return <div className=\"bg-gray-800 p-4 rounded shadow-sm\"><div className=\"text-sm text-gray-300 mb-2\">{title}</div><div>{children}</div></div>; }
function formatNumber(n){ return Number(n).toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2}); }
function today(){ const d=new Date(); const yyyy=d.getFullYear(); const mm=String(d.getMonth()+1).padStart(2,'0'); const dd=String(d.getDate()).padStart(2,'0'); return `${yyyy}-${mm}-${dd}`; }
function moodColor(name){ if(name==='Bom') return '#34D399'; if(name==='Neutro') return '#FBBF24'; return '#F87171'; }

function RulesEditor(){ const [rules,setRules]=useState([{id:1,text:'Não deixe sua ansiedade operar por você.',checked:false,reminder:false},{id:2,text:'Não efetuar operações contra a tendência.',checked:false,reminder:false},{id:3,text:'Não opere após às 13 horas.',checked:false,reminder:true},{id:4,text:'Pare de operar se atingir a meta diária.',checked:false,reminder:true}]); function addRule(){ const t=prompt('Nova regra:'); if(!t) return; setRules(r=>[...r,{id:Date.now(),text:t,checked:false,reminder:false}]); } return <div><div className=\"space-y-2\">{rules.map(rule=>(<div key={rule.id} className=\"flex items-center justify-between bg-gray-900 p-2 rounded\"><div><div className=\"font-medium\">{rule.text}</div><div className=\"text-xs text-gray-400\">{rule.reminder? 'Lembrete ativado':''}</div></div><div className=\"flex items-center gap-2\"><button onClick={()=>setRules(rs=>rs.map(r=> r.id===rule.id? {...r,checked:!r.checked}: r))} className={`px-2 py-1 rounded ${rule.checked? 'bg-green-600':'bg-gray-700'}`}>{rule.checked? 'Feito':'Marcar'}</button><button onClick={()=>setRules(rs=>rs.filter(r=>r.id!==rule.id))} className=\"px-2 py-1 rounded bg-red-600\">Apagar</button></div></div>))}</div><div className=\"mt-3 flex gap-2\"><button onClick={addRule} className=\"px-4 py-2 rounded bg-blue-600\">+ Adicionar Regra</button></div></div>; }