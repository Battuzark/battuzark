# Meu Diário de Trader — Electron + Vite + SQLite (Option C)

Este repositório contém um protótipo pronto do aplicativo "Meu Diário de Trader".
Ele foi planejado para ser empacotado como um executável Windows (.exe) usando **electron-builder**.

## O que está incluído
- Frontend: React + Vite (src/)
- Electron: main & preload (electron/)
- SQLite: pasta `database/` com arquivo `journal.sqlite` (inicial vazio)
- Configuração do electron-builder no package.json
- Workflow para GitHub Actions (sugestão) para gerar o .exe automaticamente

## Como gerar o executável (local)
1. Instale o Node.js (versão LTS) e Git.
2. Abra PowerShell/Terminal na pasta do projeto.
3. Rode `npm install` (pode demorar, pois há dependências do Electron).
4. Para desenvolvimento com live reload:
   - `npm run electron:dev`
   - Isso executa `vite` e em seguida abre o Electron apontando para `http://localhost:5173`.
5. Para gerar o instalador Windows:
   - `npm run dist`
   - Isso roda `vite build` e depois `electron-builder` para criar `dist_electron/` com o instalador.

> Observação: Para build no Windows você precisa do ambiente correto. Se estiver em Linux ou macOS, configure `wine`/`mono` se necessário para gerar instaladores Windows.

## Gerar o .exe sem construir localmente (recomendado para quem não quer instalar toolchain)
1. Faça um repositório no GitHub e envie todo este projeto.
2. Adicione um GitHub Actions workflow (fornecido no README) que roda o `npm run dist` em um runner Windows e publica o artefato.
3. Ao abrir o workflow, o artifact com o instalador `.exe` será gerado e disponível para download.

## Observações sobre o banco de dados
- O código inclui o arquivo `database/journal.sqlite`. Você pode usar `better-sqlite3` no Electron main/preload para operações seguras.

---

Se quiser, eu já crio também o workflow do GitHub Actions e um arquivo `.yml` pronto para você colar no repositório — assim o `.exe` é gerado automaticamente quando você fizer push. Diga se quer que eu inclua o workflow.
