const { contextBridge } = require('electron');
const path = require('path');

contextBridge.exposeInMainWorld('electronAPI', {
  getDatabasePath: () => path.join(__dirname, '..', 'database', 'journal.sqlite')
});